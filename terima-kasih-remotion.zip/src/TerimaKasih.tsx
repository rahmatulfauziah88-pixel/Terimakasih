import React from 'react';
import {
  AbsoluteFill,
  Easing,
  Img,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont as loadSerif} from '@remotion/google-fonts/CormorantGaramond';
import {loadFont as loadSans} from '@remotion/google-fonts/Montserrat';

const serif = loadSerif('normal', {weights: ['500', '600'], subsets: ['latin']});
const sans = loadSans('normal', {weights: ['400', '500'], subsets: ['latin']});

// ====== PENGATURAN MUDAH DIUBAH ======
const JUDUL = 'Terima Kasih';
const SUBJUDUL = 'kepada para mitra yang telah menyempurnakan hari istimewa ini';

const LOGOS = [
  {file: 'logos/01_Rifa_Makeup.png', scale: 1.0},
  {file: 'logos/02_JOI_Photography.png', scale: 1.0},
  {file: 'logos/03_Heniyuda_Dekorasi.png', scale: 1.0},
  {file: 'logos/04_El_Syafa.png', scale: 1.0},
];
// =====================================

const GOLD = '#d9bd8c';
const GOLD_SOFT = 'rgba(217,189,140,0.38)';

const CARD_W = 400;
const CARD_H = 430;
const GAP = 40;
const CARDS_TOP = 470;

const ease = Easing.bezier(0.22, 1, 0.36, 1);

const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height, durationInFrames} = useVideoConfig();
  const items = Array.from({length: 46}).map((_, i) => {
    const x = random(`x${i}`) * width;
    const size = 2 + random(`s${i}`) * 4;
    const speed = 0.25 + random(`v${i}`) * 0.55;
    const phase = random(`p${i}`) * height;
    const y = height + 20 - ((frame * speed * 2 + phase) % (height + 40));
    const drift = Math.sin(frame / 40 + i) * 18;
    const tw = 0.25 + 0.75 * Math.abs(Math.sin(frame / 22 + i * 1.7));
    return {x: x + drift, y, size, o: tw * (0.15 + random(`o${i}`) * 0.4)};
  });
  const fadeOut = interpolate(frame, [durationInFrames - 30, durationInFrames], [1, 0], {
    extrapolateLeft: 'clamp',
  });
  return (
    <AbsoluteFill style={{opacity: fadeOut}}>
      {items.map((p, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: p.x,
            top: p.y,
            width: p.size,
            height: p.size,
            borderRadius: '50%',
            background: GOLD,
            opacity: p.o,
            boxShadow: `0 0 ${p.size * 4}px ${GOLD}`,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const glowX = 50 + Math.sin(frame / 90) * 8;
  const glowY = 48 + Math.cos(frame / 110) * 6;
  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse at ${glowX}% ${glowY}%, #3a2c1f 0%, #1c1510 45%, #0b0807 100%)`,
      }}
    >
      <AbsoluteFill
        style={{
          background:
            'radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.55) 100%)',
        }}
      />
    </AbsoluteFill>
  );
};

const Frame: React.FC = () => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [5, 40], [0, 1], {extrapolateRight: 'clamp'});
  const inset = 44;
  const corner = (style: React.CSSProperties) => (
    <div
      style={{
        position: 'absolute',
        width: 70,
        height: 70,
        borderColor: GOLD,
        borderStyle: 'solid',
        borderWidth: 0,
        opacity: 0.85,
        ...style,
      }}
    />
  );
  return (
    <AbsoluteFill style={{opacity: o}}>
      <div
        style={{
          position: 'absolute',
          inset,
          border: `1px solid ${GOLD_SOFT}`,
        }}
      />
      {corner({left: inset - 6, top: inset - 6, borderTopWidth: 2, borderLeftWidth: 2})}
      {corner({right: inset - 6, top: inset - 6, borderTopWidth: 2, borderRightWidth: 2})}
      {corner({left: inset - 6, bottom: inset - 6, borderBottomWidth: 2, borderLeftWidth: 2})}
      {corner({right: inset - 6, bottom: inset - 6, borderBottomWidth: 2, borderRightWidth: 2})}
    </AbsoluteFill>
  );
};

const Title: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  // Judul mulai di tengah layar lalu naik ke atas saat logo muncul
  const lift = interpolate(frame, [78, 120], [305, 0], {
    easing: ease,
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const titleIn = spring({frame: frame - 12, fps, config: {damping: 200}, durationInFrames: 40});
  const titleY = interpolate(titleIn, [0, 1], [40, 0]);
  const tracking = interpolate(frame, [12, 90], [0.18, 0.06], {
    easing: ease,
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const lineW = interpolate(frame, [34, 74], [0, 460], {
    easing: ease,
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const subIn = interpolate(frame, [52, 80], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        position: 'absolute',
        top: 110,
        left: 0,
        right: 0,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        transform: `translateY(${lift}px)`,
      }}
    >
      <div
        style={{
          fontFamily: serif.fontFamily,
          fontWeight: 600,
          fontSize: 132,
          lineHeight: 1.05,
          letterSpacing: `${tracking}em`,
          color: '#f4ead7',
          opacity: titleIn,
          transform: `translateY(${titleY}px)`,
          textShadow: '0 0 40px rgba(217,189,140,0.35)',
          paddingLeft: `${tracking}em`,
        }}
      >
        {JUDUL}
      </div>
      <div style={{display: 'flex', alignItems: 'center', gap: 18, marginTop: 14}}>
        <div style={{width: lineW / 2, height: 1, background: GOLD}} />
        <div
          style={{
            width: 10,
            height: 10,
            background: GOLD,
            transform: 'rotate(45deg)',
            opacity: lineW > 20 ? 1 : 0,
          }}
        />
        <div style={{width: lineW / 2, height: 1, background: GOLD}} />
      </div>
      <div
        style={{
          marginTop: 26,
          fontFamily: sans.fontFamily,
          fontWeight: 400,
          fontSize: 32,
          letterSpacing: '0.12em',
          color: GOLD,
          opacity: subIn,
          transform: `translateY(${(1 - subIn) * 14}px)`,
        }}
      >
        {SUBJUDUL}
      </div>
    </div>
  );
};

const LogoCard: React.FC<{file: string; index: number; scale: number}> = ({file, index, scale}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const start = 96 + index * 24;

  const p = spring({frame: frame - start, fps, config: {damping: 18, stiffness: 90, mass: 0.9}});
  const opacity = interpolate(frame, [start, start + 18], [0, 1], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const blur = interpolate(frame, [start, start + 22], [14, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const y = interpolate(p, [0, 1], [70, 0]);
  const s = interpolate(p, [0, 1], [0.9, 1]);
  const float = Math.sin((frame + index * 22) / 38) * 5;

  // kilau cahaya melintas satu kali per kartu
  const sweepStart = 215 + index * 28;
  const sweep = interpolate(frame, [sweepStart, sweepStart + 36], [-60, 160], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  return (
    <div
      style={{
        width: CARD_W,
        height: CARD_H,
        position: 'relative',
        borderRadius: 26,
        overflow: 'hidden',
        opacity,
        filter: `blur(${blur}px)`,
        transform: `translateY(${y + float}px) scale(${s})`,
        background: 'linear-gradient(160deg, rgba(255,255,255,0.075), rgba(255,255,255,0.02))',
        border: `1px solid ${GOLD_SOFT}`,
        boxShadow: '0 30px 60px rgba(0,0,0,0.45), inset 0 0 40px rgba(217,189,140,0.05)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Img
        src={staticFile(file)}
        style={{
          maxWidth: (CARD_W - 60) * scale,
          maxHeight: (CARD_H - 80) * scale,
          objectFit: 'contain',
        }}
      />
      <div
        style={{
          position: 'absolute',
          top: 0,
          bottom: 0,
          left: `${sweep}%`,
          width: '28%',
          transform: 'skewX(-18deg)',
          background:
            'linear-gradient(90deg, rgba(255,240,210,0), rgba(255,240,210,0.16), rgba(255,240,210,0))',
        }}
      />
    </div>
  );
};

export const TerimaKasih: React.FC = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const fadeIn = interpolate(frame, [0, 14], [0, 1], {extrapolateRight: 'clamp'});
  const fadeOut = interpolate(frame, [durationInFrames - 24, durationInFrames], [1, 0], {
    extrapolateLeft: 'clamp',
  });

  return (
    <AbsoluteFill style={{background: '#0b0807', opacity: fadeIn * fadeOut}}>
      <Background />
      <Particles />
      <Frame />
      <Title />
      <div
        style={{
          position: 'absolute',
          top: CARDS_TOP,
          left: 0,
          right: 0,
          display: 'flex',
          justifyContent: 'center',
          gap: GAP,
        }}
      >
        {LOGOS.map((l, i) => (
          <LogoCard key={l.file} file={l.file} index={i} scale={l.scale} />
        ))}
      </div>
    </AbsoluteFill>
  );
};
