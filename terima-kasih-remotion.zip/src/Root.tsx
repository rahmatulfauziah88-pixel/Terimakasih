import React from 'react';
import {Composition} from 'remotion';
import {TerimaKasih} from './TerimaKasih';

export const FPS = 30;
export const DURATION_SECONDS = 15;

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="TerimaKasih"
      component={TerimaKasih}
      durationInFrames={FPS * DURATION_SECONDS}
      fps={FPS}
      width={1920}
      height={1080}
    />
  );
};
