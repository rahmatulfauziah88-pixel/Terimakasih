// Semua waktu dalam frame (30 FPS). Total 28 detik.
export const FPS = 30;
export const WIDTH = 3840;
export const HEIGHT = 2160;
export const TOTAL_FRAMES = 840;

export const T = {
  // pembuka: bunga mekar dari sudut, lalu teks
  titleIn: 75,
  msgIn: 126,
  engIn: 176,
  introOutStart: 240,
  introOutEnd: 268,
  // logo tampil satu per satu
  logoStart: 272,
  logoStep: 60,
  logoWindow: 72,
  // adegan penutup
  finalStart: 590,
  fadeOutStart: 790,
};

// Musik opsional: letakkan file di folder public/ lalu isi nama berkasnya, contoh 'musik.mp3'.
// null = tanpa audio.
export const MUSIC_FILE: string | null = null;
