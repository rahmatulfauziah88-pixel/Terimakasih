import React from 'react';
import {Composition} from 'remotion';
import {EmeraldThankYou} from './EmeraldThankYou';
import {FPS, TOTAL_FRAMES, WIDTH, HEIGHT} from './timeline';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="EmeraldThankYou"
    component={EmeraldThankYou}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
  />
);
