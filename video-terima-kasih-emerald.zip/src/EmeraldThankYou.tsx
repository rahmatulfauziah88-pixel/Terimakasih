import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Easing,
  Img,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {loadFont as loadSerif} from '@remotion/google-fonts/CormorantGaramond';
import scene from './scene.json';
import {FPS, HEIGHT, MUSIC_FILE, T, TOTAL_FRAMES, WIDTH} from './timeline';

const serif = loadSerif('normal', {weights: ['500', '600'], subsets: ['latin']});
const serifItalic = loadSerif('italic', {weights: ['500'], subsets: ['latin']});

// ================= TEKS (persis sesuai permintaan) =================
const TITLE = 'TERIMA KASIH';
const MSG_1 = 'Kepada seluruh partner dan vendor';
const MSG_2 = 'yang telah menjadi bagian dari kebahagiaan kami.';
const ENG = 'Your support made our special day even more beautiful.';
// ====================================================================

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const easeOut = Easing.bezier(0.22, 1, 0.36, 1);

const CHAMPAGNE = '#e6cf9c';
const IVORY = '#f5ecda';

// ---------------------------------------------------------------- Bunga
type El = (typeof scene.elements)[number];
const CORNER_DIR: Record<string, [number, number]> = {tl: [-1, -1], tr: [1, -1], bl: [-1, 1], br: [1, 1]};
const KIND_DELAY: Record<string, number> = {sprig: 6, gyp: 24, rose: 34, vine: 52};
const CORNER_DELAY: Record<string, number> = {tl: 0, tr: 7, bl: 14, br: 21};

const Flora: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const sorted: El[] = [...scene.elements].sort((a, b) => a.z - b.z || a.order - b.order);
  return (
    <AbsoluteFill>
      {sorted.map((e) => {
        const delay = KIND_DELAY[e.kind] + CORNER_DELAY[e.corner] + (e.order % 4) * 3;
        const p = spring({
          frame: Math.max(0, frame - delay),
          fps,
          config: {damping: 200},
          durationInFrames: 70,
        });
        const [dx, dy] = CORNER_DIR[e.corner];
        const off = (1 - p) * 170;
        const sway = Math.sin((frame / e.per) * Math.PI * 2 + e.ph) * e.sway;
        const breathe = e.kind === 'rose' ? 1 + 0.007 * Math.sin(frame / 80 + e.ph) : 1;
        const s = (0.8 + 0.2 * p) * breathe;
        return (
          <Img
            key={`${e.corner}-${e.order}`}
            src={staticFile(`flora/${e.src}.png`)}
            style={{
              position: 'absolute',
              left: e.x - e.ax * e.w,
              top: e.y - e.ay * e.h,
              width: e.w,
              height: e.h,
              opacity: p,
              transformOrigin: `${e.ax * 100}% ${e.ay * 100}%`,
              transform: `translate(${dx * off}px, ${dy * off}px) rotate(${e.rot + sway}deg) scale(${
                (e.fx ? -1 : 1) * s
              }, ${(e.fy ? -1 : 1) * s})`,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------- Partikel emas
const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  const fadeIn = interpolate(frame, [20, 80], [0, 1], clamp);
  const items = Array.from({length: 64}).map((_, i) => {
    const x0 = random(`px${i}`) * WIDTH;
    const size = 4 + random(`ps${i}`) * 9;
    const speed = 0.5 + random(`pv${i}`) * 1.1;
    const phase = random(`pp${i}`) * (HEIGHT + 300);
    const y = HEIGHT + 100 - ((frame * speed + phase) % (HEIGHT + 300));
    const x = x0 + Math.sin(frame / 55 + i) * 36;
    const tw = 0.3 + 0.7 * Math.abs(Math.sin(frame / 26 + i * 1.9));
    return {x, y, size, o: tw * (0.18 + random(`po${i}`) * 0.45)};
  });
  return (
    <AbsoluteFill style={{opacity: fadeIn}}>
      {items.map((p, i) => (
        <div
          key={i}
          style={{
            position: 'absolute',
            left: p.x,
            top: p.y,
            width: p.size,
            height: p.size,
            borderRadius: '50%',
            background: '#f3dfae',
            opacity: p.o,
            boxShadow: `0 0 ${p.size * 3}px ${p.size * 0.6}px rgba(243,223,174,0.55)`,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------- Kilau cahaya
const Sweep: React.FC<{start: number; dur?: number}> = ({start, dur = 64}) => {
  const frame = useCurrentFrame();
  const f = frame - start;
  if (f < 0 || f > dur) return null;
  const x = interpolate(f, [0, dur], [-1300, WIDTH + 400], {easing: Easing.inOut(Easing.sin)});
  return (
    <div
      style={{
        position: 'absolute',
        top: -200,
        left: 0,
        width: 900,
        height: HEIGHT + 400,
        transform: `translateX(${x}px) skewX(-18deg)`,
        background:
          'linear-gradient(90deg, rgba(255,232,180,0), rgba(255,232,180,0.11), rgba(255,232,180,0))',
      }}
    />
  );
};

// ---------------------------------------------------------------- Teks emas timbul
const GoldText: React.FC<{text: string; size: number; tracking: number; shimmerAt?: number}> = ({
  text,
  size,
  tracking,
  shimmerAt = 0,
}) => {
  const frame = useCurrentFrame();
  const pos = interpolate(frame - shimmerAt, [0, 110], [160, -60], clamp);
  return (
    <div
      style={{
        fontFamily: serif.fontFamily,
        fontWeight: 600,
        fontSize: size,
        lineHeight: 1.05,
        letterSpacing: `${tracking}em`,
        paddingLeft: `${tracking}em`,
        whiteSpace: 'nowrap',
        backgroundImage:
          'linear-gradient(105deg, rgba(255,255,255,0) 42%, rgba(255,255,255,0.65) 50%, rgba(255,255,255,0) 58%), linear-gradient(180deg, #fbefc9 0%, #e6c98b 36%, #b88f4c 52%, #efdba6 78%, #d7b56f 100%)',
        backgroundSize: '260% 100%, 100% 100%',
        backgroundPosition: `${pos}% 0, 0 0`,
        backgroundRepeat: 'no-repeat',
        WebkitBackgroundClip: 'text',
        backgroundClip: 'text',
        color: 'transparent',
        WebkitTextFillColor: 'transparent',
        filter:
          'drop-shadow(0px -2px 0px rgba(255,248,225,0.5)) drop-shadow(0px 4px 0px rgba(58,36,8,0.6)) drop-shadow(0px 18px 26px rgba(0,0,0,0.45))',
      }}
    >
      {text}
    </div>
  );
};

const Line: React.FC<{
  text: string;
  size: number;
  y: number;
  opacity: number;
  italic?: boolean;
  color?: string;
}> = ({text, size, y, opacity, italic, color = IVORY}) => (
  <div
    style={{
      position: 'absolute',
      left: 0,
      right: 0,
      top: y - size * 0.6,
      textAlign: 'center',
      fontFamily: italic ? serifItalic.fontFamily : serif.fontFamily,
      fontStyle: italic ? 'italic' : 'normal',
      fontWeight: 500,
      fontSize: size,
      letterSpacing: '0.02em',
      color,
      opacity,
      transform: `translateY(${(1 - opacity) * 22}px)`,
      textShadow: '0 4px 18px rgba(0,0,0,0.55)',
    }}
  >
    {text}
  </div>
);

const Divider: React.FC<{y: number; w: number; opacity: number}> = ({y, w, opacity}) => (
  <Img
    src={staticFile('flora/divider.png')}
    style={{
      position: 'absolute',
      left: (WIDTH - w) / 2,
      top: y - (w * 110) / 1300 / 2,
      width: w,
      height: (w * 110) / 1300,
      opacity,
    }}
  />
);

// ---------------------------------------------------------------- Adegan pembuka
const Intro: React.FC = () => {
  const frame = useCurrentFrame();
  const out = interpolate(frame, [T.introOutStart, T.introOutEnd], [1, 0], clamp);
  if (out <= 0) return null;
  const tIn = interpolate(frame, [T.titleIn, T.titleIn + 44], [0, 1], {...clamp, easing: easeOut});
  const tracking = interpolate(frame, [T.titleIn, T.titleIn + 90], [0.2, 0.08], {...clamp, easing: easeOut});
  const m1 = interpolate(frame, [T.msgIn, T.msgIn + 36], [0, 1], {...clamp, easing: easeOut});
  const m2 = interpolate(frame, [T.msgIn + 14, T.msgIn + 50], [0, 1], {...clamp, easing: easeOut});
  const en = interpolate(frame, [T.engIn, T.engIn + 40], [0, 1], {...clamp, easing: easeOut});
  return (
    <AbsoluteFill style={{opacity: out}}>
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 860 - 130,
          display: 'flex',
          justifyContent: 'center',
          opacity: tIn,
          transform: `translateY(${(1 - tIn) * 40}px)`,
        }}
      >
        <GoldText text={TITLE} size={250} tracking={tracking} shimmerAt={T.titleIn + 30} />
      </div>
      <Divider y={1040} w={1100} opacity={tIn} />
      <Line text={MSG_1} size={86} y={1190} opacity={m1} />
      <Line text={MSG_2} size={86} y={1300} opacity={m2} />
      <Line text={ENG} size={78} y={1480} opacity={en} italic color={CHAMPAGNE} />
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------- Logo satu per satu
const Glow: React.FC<{cx: number; cy: number; w: number; h: number; opacity: number}> = ({cx, cy, w, h, opacity}) => (
  <div
    style={{
      position: 'absolute',
      left: cx - w / 2,
      top: cy - h / 2,
      width: w,
      height: h,
      opacity,
      background:
        'radial-gradient(ellipse at center, rgba(246,224,170,0.22) 0%, rgba(246,224,170,0.09) 42%, rgba(246,224,170,0) 70%)',
    }}
  />
);

const SingleLogo: React.FC<{index: number}> = ({index}) => {
  const frame = useCurrentFrame();
  const L = scene.logos[index];
  const start = T.logoStart + index * T.logoStep;
  const f = frame - start;
  if (f < 0 || f > T.logoWindow) return null;
  const op = interpolate(f, [0, 20, T.logoWindow - 14, T.logoWindow], [0, 1, 1, 0], clamp);
  const push = interpolate(f, [0, T.logoWindow], [0.96, 1.02]);
  const {cx, cy, w, h} = L.single;
  return (
    <AbsoluteFill>
      <Glow cx={cx} cy={cy} w={w * 1.9 + 500} h={h * 1.7 + 500} opacity={op} />
      <div style={{position: 'absolute', inset: 0, transform: `scale(${push})`, transformOrigin: `${cx}px ${cy}px`, opacity: op}}>
        <Img
          src={staticFile(`logos/${L.file}`)}
          style={{position: 'absolute', left: cx - w / 2, top: cy - h / 2, width: w, height: h}}
        />
      </div>
      <Divider y={Math.min(cy + h / 2 + 120, 1760)} w={1000} opacity={op * 0.9} />
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------- Adegan penutup
const Final: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const f = frame - T.finalStart;
  if (f < 0) return null;
  const tIn = interpolate(f, [0, 40], [0, 1], {...clamp, easing: easeOut});
  const en = interpolate(f, [86, 126], [0, 1], {...clamp, easing: easeOut});
  const glow = interpolate(f, [0, 60], [0, 1], clamp);
  return (
    <AbsoluteFill>
      <Glow cx={1920} cy={1140} w={2500} h={1250} opacity={glow} />
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          top: 395 - 112,
          display: 'flex',
          justifyContent: 'center',
          opacity: tIn,
          transform: `translateY(${(1 - tIn) * 30}px)`,
        }}
      >
        <GoldText text={TITLE} size={210} tracking={0.08} shimmerAt={T.finalStart + 20} />
      </div>
      <Divider y={560} w={1000} opacity={tIn} />
      {scene.logos.map((L, i) => {
        const p = spring({frame: Math.max(0, f - (16 + i * 10)), fps, config: {damping: 200}, durationInFrames: 50});
        const {cx, cy, w, h} = L.final;
        return (
          <Img
            key={L.file}
            src={staticFile(`logos/${L.file}`)}
            style={{
              position: 'absolute',
              left: cx - w / 2,
              top: cy - h / 2,
              width: w,
              height: h,
              opacity: p,
              transform: `translateY(${(1 - p) * 26}px) scale(${0.96 + 0.04 * p})`,
            }}
          />
        );
      })}
      <Line text={ENG} size={74} y={1800} opacity={en} italic color={CHAMPAGNE} />
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------- Komposisi utama
export const EmeraldThankYou: React.FC = () => {
  const frame = useCurrentFrame();
  const push = interpolate(frame, [0, TOTAL_FRAMES], [1.0, 1.045]);
  const black =
    1 -
    interpolate(frame, [0, 30], [0, 1], clamp) +
    interpolate(frame, [T.fadeOutStart, TOTAL_FRAMES - 1], [0, 1], clamp);
  const vol = interpolate(frame, [0, 45, T.fadeOutStart, TOTAL_FRAMES], [0, 0.9, 0.9, 0], clamp);

  return (
    <AbsoluteFill style={{background: '#021a14'}}>
      {MUSIC_FILE ? <Audio src={staticFile(MUSIC_FILE)} volume={vol} /> : null}

      {/* latar + bunga bergerak perlahan (kamera sinematik) */}
      <AbsoluteFill style={{transform: `scale(${push})`, transformOrigin: '50% 48%'}}>
        <Img src={staticFile('bg/bg_emerald.jpg')} style={{width: WIDTH, height: HEIGHT}} />
        <Flora />
        <Particles />
      </AbsoluteFill>

      <Sweep start={118} />
      <Sweep start={T.introOutStart + 8} />
      <Sweep start={T.finalStart + 6} />

      <Intro />
      {scene.logos.map((_, i) => (
        <SingleLogo key={i} index={i} />
      ))}
      <Final />

      <AbsoluteFill style={{background: '#010d0a', opacity: Math.min(1, Math.max(0, black))}} />
    </AbsoluteFill>
  );
};
