# Video Terima Kasih — Luxury Emerald Botanical (4K, 28 detik)

## Render di GitHub
1. Unggah seluruh isi folder ini ke repo (branch `main`).
2. Tab **Actions** → "Render Video Terima Kasih Emerald" → **Run workflow**.
   - `preview-1080p` : render cepat setengah resolusi untuk mengecek tampilan dulu.
   - `full-4k`       : hasil akhir 3840x2160, 30 FPS.
3. Setelah selesai, unduh MP4 dari **Artifacts**.

## Mengatur
- Teks: bagian atas `src/EmeraldThankYou.tsx` (jangan diubah bila ingin persis).
- Waktu adegan: `src/timeline.ts`.
- Musik (opsional): taruh file audio di `public/`, lalu isi `MUSIC_FILE` di `src/timeline.ts`.
- Logo asli ada di `public/logos/`. `02_JOI_Photography_x3.png` hanyalah salinan yang diperbesar
  (Lanczos 3x) khusus untuk render; berkas asli `02_JOI_Photography.png` tidak diubah.
